
- 3 blocs s'affichent successivement lorsqu'on clique sur le précédent

- Le dernier clic permet d'activer le chant 'Joyeux Anniversaire', message qui est d'ailleurs alors affiché dans tous les blocs

- La barre "controls" du chant permet de mettre celui-ci en pause, ou de modifier le volume, ou encore d'avancer dans la piste audio, alors que les bloc 3 et 1 vont successivement s'éclipser...
